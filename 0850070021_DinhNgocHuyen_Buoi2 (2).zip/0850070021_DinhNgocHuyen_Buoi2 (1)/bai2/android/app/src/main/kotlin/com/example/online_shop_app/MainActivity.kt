package com.example.online_shop_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
