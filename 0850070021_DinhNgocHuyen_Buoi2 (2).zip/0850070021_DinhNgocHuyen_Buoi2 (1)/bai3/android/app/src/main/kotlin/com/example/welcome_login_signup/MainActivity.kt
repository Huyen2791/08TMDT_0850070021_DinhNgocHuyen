package com.example.welcome_login_signup

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
